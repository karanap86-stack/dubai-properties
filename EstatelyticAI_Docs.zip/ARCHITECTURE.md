# Dubai Properties Platform - Architecture & Data Flow

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         DUBAI PROPERTIES                         │
│                      AI-Powered Platform                         │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                      USER INTERFACE LAYER                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │              NAVBAR (4 Tabs Navigation)                 │  │
│  │  Discover | Compare | AI Agent | Export                │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │
│  │  Discover    │  │   Compare    │  │  AI Agent    │  ...   │
│  │   Screen     │  │   Screen     │  │   Screen     │         │
│  └──────────────┘  └──────────────┘  └──────────────┘         │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                    COMPONENT LAYER (React)                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─────────────┐  ┌─────────────────┐  ┌──────────────────┐   │
│  │  FilterPanel│  │ ProjectShowcase │  │PropertyComparison│   │
│  │             │  │                 │  │                  │   │
│  │ • Filters   │  │ • Swipe cards   │  │ • ROI calc       │   │
│  │ • Sliders   │  │ • Select items  │  │ • 5-yr proj      │   │
│  │ • Checkboxes│  │ • Display props │  │ • Comparison     │   │
│  └─────────────┘  └─────────────────┘  └──────────────────┘   │
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐     │
│  │AIContentGen. │  │GoogleSheet   │  │  HeroSection   │     │
│  │              │  │  Integration │  │                │     │
│  │• Generate    │  │              │  │• Welcome        │     │
│  │• Multiple    │  │• Export data │  │• Search bar     │     │
│  │  types       │  │• Email lead  │  │• Stats display  │     │
│  └──────────────┘  └──────────────┘  └──────────────────┘     │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                    STATE MANAGEMENT LAYER                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌────────────────────────────────────────────────────────┐    │
│  │          ProjectContext (Global State)                │    │
│  ├────────────────────────────────────────────────────────┤    │
│  │  • projects: Array of all properties                  │    │
│  │  • loading: Boolean for loading state                 │    │
│  │  • setProjects: Update function                       │    │
│  └────────────────────────────────────────────────────────┘    │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                    BUSINESS LOGIC LAYER                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌───────────────────────────────────────────────────────┐     │
│  │           projectService.js                          │     │
│  ├───────────────────────────────────────────────────────┤     │
│  │  • getAllProjects()        → Fetch all properties    │     │
│  │  • getProjectsByFilter()   → Filter based on criteria│     │
│  │  • calculateROI()          → ROI computation         │     │
│  │  • calculateAppreciation() → Appreciation calc       │     │
│  │  • getRoiReasons()         → Explanation text        │     │
│  └───────────────────────────────────────────────────────┘     │
│                                                                   │
│  ┌───────────────────────────────────────────────────────┐     │
│  │           apiConfig.js                               │     │
│  ├───────────────────────────────────────────────────────┤     │
│  │  • API_CONFIG object with all endpoints              │     │
│  │  • exportToGoogleSheets()  → Sheet integration       │     │
│  │  • sendLeadEmail()         → Email service           │     │
│  │  • generateAIContent()     → AI generation           │     │
│  └───────────────────────────────────────────────────────┘     │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                    DATA LAYER                                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────────┐  ┌──────────────────┐                   │
│  │  DUBAI PROJECTS  │  │ ABU DHABI PROJECTS│                  │
│  │                  │  │                  │                  │
│  │ 6 Properties     │  │ 6 Properties     │                  │
│  │ (Mock data)      │  │ (Mock data)      │                  │
│  └──────────────────┘  └──────────────────┘                   │
│           ↓                      ↓                              │
│     [Can connect to real          [Backend API]                │
│      property APIs]               [Database]                   │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                    EXTERNAL SERVICES                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────┐ │
│  │  GOOGLE SHEETS   │  │   EMAIL SERVICE  │  │  AI API      │ │
│  │                  │  │                  │  │  (OpenAI)    │ │
│  │ • Export data    │  │ • SendGrid       │  │  • Generate  │ │
│  │ • Store leads    │  │ • Mailgun        │  │    content   │ │
│  │ • Organize info  │  │ • SMTP           │  │  • Multiple  │ │
│  │                  │  │ • Send leads     │  │    templates │ │
│  └──────────────────┘  └──────────────────┘  └──────────────┘ │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Data Flow Diagrams

### 1. User Browsing Properties
```
┌─────────────┐
│  User Opens │
│  Discover   │
│    Tab      │
└──────┬──────┘
       ↓
┌──────────────────────┐
│ ProjectShowcase      │
│ triggers useEffect   │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ Load projects from   │
│ ProjectContext       │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ Display first card   │
│ with image, ROI, etc │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ User swipes card     │
│ (next/previous)      │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ Update currentIndex  │
│ state                │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ Display next card    │
└──────────────────────┘
```

### 2. User Filtering Properties
```
┌──────────────┐
│ User adjusts │
│ filter in    │
│ FilterPanel  │
└──────┬───────┘
       ↓
┌──────────────┐
│ Filter state │
│ updates      │
└──────┬───────┘
       ↓
┌────────────────────┐
│ Calls setFilters() │
│ with new values    │
└──────┬─────────────┘
       ↓
┌──────────────────────┐
│ ProjectShowcase      │
│ useEffect triggered  │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ Filters projects:    │
│ • Budget range       │
│ • Location match     │
│ • Property type      │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ Display filtered     │
│ results             │
└──────────────────────┘
```

### 3. User Comparing Properties
```
┌──────────────┐
│ User selects │
│ projects in  │
│ Discover tab │
└──────┬───────┘
       ↓
┌──────────────────────┐
│ Click heart icon on  │
│ property card        │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ Add to selectedProjects│
│ array (max 5)        │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ Click Compare tab    │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ PropertyComparison   │
│ receives selected    │
│ projects as prop     │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ Calculate for each:  │
│ • ROI percentage     │
│ • Appreciation %     │
│ • 5-year projection  │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ Display comparison   │
│ table & analysis     │
└──────────────────────┘
```

### 4. User Generating Content
```
┌──────────────┐
│ Go to AI     │
│ Agent tab    │
└──────┬───────┘
       ↓
┌──────────────────────┐
│ Select content type: │
│ • Description        │
│ • Marketing copy     │
│ • Social post        │
│ • Headline           │
│ • Email campaign     │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ Select tone:         │
│ • Professional       │
│ • Casual             │
│ • Luxury             │
│ • Family-Friendly    │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ Click "Generate"     │
│ button               │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ [Backend/API Call]   │
│ Send to OpenAI or    │
│ similar service      │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ Show loading state   │
│ (spinner)            │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ Receive generated    │
│ content from AI      │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ Display in output    │
│ panel                │
└──────┬───────────────┘
       ↓
┌──────────────────────┐
│ User can:            │
│ • Copy to clipboard  │
│ • Download as file   │
│ • Edit and refine    │
└──────────────────────┘
```

### 5. User Exporting Data
```
┌──────────────┐
│ Go to Export │
│ tab          │
└──────┬───────┘
       ↓
┌──────────────────────┐
│ Fill customer info:  │
│ • Name               │
│ • Email              │
│ • Phone              │
│ • Budget             │
│ • Preferences        │
└──────┬───────────────┘
       ↓
┌─────────────────────────────┐
│ Choose export method:       │
│ A) Google Sheets            │
│ B) Send Email               │
└──────┬──────────────────────┘
       ↓
   ┌───┴────┐
   ↓        ↓
┌──────┐ ┌──────────┐
│Sheets│ │Email     │
└──┬───┘ └────┬─────┘
   │          │
   ↓          ↓
┌──────────┐ ┌────────────┐
│Paste     │ │Click Send  │
│sheet link│ │Email       │
└──┬───────┘ └────┬───────┘
   │              │
   ↓              ↓
┌──────────────────────────┐
│ [Backend/API Call]       │
│ Send data + auth token   │
└──────┬───────────────────┘
       ↓
┌──────────────────────────┐
│ Validate & process:      │
│ • Verify customer info   │
│ • Confirm auth           │
│ • Prepare data format    │
└──────┬───────────────────┘
       ↓
┌──────────────────────────┐
│ A) Write to Google Sheet │
│ B) Send via email        │
└──────┬───────────────────┘
       ↓
┌──────────────────────────┐
│ Show success message     │
│                          │
│ "Data exported          │
│  successfully!"          │
└──────────────────────────┘
```

---

## 🔗 Component Dependencies

```
App
├── Navbar (controls activeTab state)
│   └── Shows 4 tabs with icons
│
├── ProjectContext (provides global project data)
│   │
│   └── All components access via useContext
│
├── Discover Tab Content
│   ├── HeroSection
│   │   └── Shows search bar & stats
│   │
│   ├── FilterPanel
│   │   ├── Budget slider
│   │   ├── Location checkboxes
│   │   ├── Type checkboxes
│   │   ├── Developer list
│   │   └── Amenities list
│   │
│   └── ProjectShowcase
│       ├── Gets projects from context
│       ├── Filters based on filter state
│       ├── Displays current card
│       ├── Handles swipe/arrow clicks
│       └── Manages selection state
│
├── Compare Tab Content
│   └── PropertyComparison
│       ├── Gets selectedProjects as prop
│       ├── Calculates ROI & appreciation
│       ├── Shows comparison table
│       └── Displays best deal analysis
│
├── AI Agent Tab Content
│   └── AIContentGenerator
│       ├── Content type selector
│       ├── Tone selector
│       ├── Generate button
│       ├── Output display
│       └── Copy/Download buttons
│
└── Export Tab Content
    └── GoogleSheetIntegration
        ├── Customer form
        ├── Sheet link input
        ├── Export to Sheets button
        ├── Send Email button
        └── Data preview table
```

---

## 📊 State Management Map

```
App Component State:
├── activeTab: 'discover' | 'compare' | 'ai' | 'export'
├── selectedProjects: Project[]
└── filters: {
    ├── budget: { min, max }
    ├── area: string[]
    ├── propertyType: string[]
    ├── developer: string[]
    ├── bedrooms: string[]
    └── amenities: string[]
}

ProjectContext State:
├── projects: Project[]
└── loading: boolean

Component Local States:
├── FilterPanel:
│   └── expandedFilter: filterType | null
│
├── ProjectShowcase:
│   ├── displayProjects: Project[]
│   ├── currentIndex: number
│   └── swipeDirection: 'left' | 'right' | null
│
├── PropertyComparison:
│   └── expandedReasons: projectId | null
│
├── AIContentGenerator:
│   ├── contentType: string
│   ├── generatedContent: string
│   └── loading: boolean
│
└── GoogleSheetIntegration:
    ├── sheetLink: string
    ├── customerInfo: {
    │   ├── name: string
    │   ├── email: string
    │   ├── phone: string
    │   ├── budget: string
    │   └── preferences: string
    ├── loading: boolean
    ├── success: boolean
    └── error: string
```

---

## 🎯 Key Integration Points

### Frontend to Backend Communication
```
Frontend (React)
    ↓ (JSON via Fetch/Axios)
Backend (Node.js/Express)
    ├→ Google Sheets API
    ├→ Email Service (SendGrid, SMTP)
    ├→ AI API (OpenAI, Anthropic)
    └→ Database (MongoDB, PostgreSQL)
    ↑ (JSON response)
Frontend (React)
```

### Real-Time Updates
```
User Action (Filter, Select, Input)
    ↓
State Update (React)
    ↓
Component Re-render
    ↓
UI Updated Instantly
```

---

This architecture ensures:
✅ Clean separation of concerns
✅ Reusable components
✅ Easy to scale
✅ Easy to test
✅ Maintainable code
✅ Smooth user experience
